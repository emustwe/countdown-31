# Desert Dune — Game Frontend (for the designer)

This package contains **only the game part** of the frontend, with the real folder
structure preserved (everything sits under `Frontend/…`). Add your **images** and **sound
files**, tweak any visuals you like, then **zip the whole folder back up and send it to me** —
I'll wire the new assets in and apply your design changes to the live game.

> You do NOT need to run anything. Just drop assets into the folders below (and/or edit the
> style/markup files), keep the folder layout the same, and re-zip.

---

## The one component that IS the game

`Frontend/src/components/dune/SlotStage.tsx` — the slot board, reels, spin button, win
banners, and the hooks that play sounds. It is shared by every place the game appears
(practice mode + live tournament matches), so **any change here changes the real game too.**

Its look comes from CSS in `Frontend/src/app/dune.css`. The game-related style classes are:
`.game-page`, `.game-bg`, `.slot-cabinet`, `.reels`, `.slot-cell`, `.monster-symbol`,
`.monster-art`, `.symbol-badge`, `.spin-button`, `.win-overlay-banner`, `.screen-flash`,
`.round-timer`, `.fireworks`. Search those in `dune.css` to find/adjust colors, sizes, glows,
and the special wild/scatter/jackpot animations.

*(Note: `Frontend/src/game/SlotRenderer.ts`, `buildSymbolTextures.ts`, `useSlotRenderer.ts`
and the loose `public/game/symbol-*.png` files are an OLD renderer that is no longer used —
included only for reference. The active symbol art is the sprite sheet described below.)*

---

## 1) SYMBOL IMAGES  → `Frontend/public/game/symbols/`

There are **10 symbols**. Please provide one image per symbol — **transparent PNG, square,
~256×256** — named by its ID:

| File to add | Symbol | Type |
|---|---|---|
| `H1.png` | Party Ogre | High-pay |
| `H2.png` | Potion Witch | High-pay |
| `H3.png` | Fire Jackal | High-pay |
| `L1.png` | Ace (A) | Low-pay |
| `L2.png` | King (K) | Low-pay |
| `L3.png` | Queen (Q) | Low-pay |
| `L4.png` | Jack (J) | Low-pay |
| `W.png`  | **Wild** | Special |
| `S.png`  | **Scatter** | Special |
| `JP.png` | **Jackpot** | Special |

Drop them in `Frontend/public/game/symbols/`. When you send it back, I'll switch the board
from the current sprite sheet to your individual images. *(The current art lives as one sprite
sheet at `Frontend/public/assets/monster-symbols.png` — you can look at it for reference, but
you don't have to edit the sprite; individual PNGs are easier.)*

## 2) BACKGROUND & FRAME  → `Frontend/public/game/`

- **Game background** (the scene behind the cabinet): currently
  `Frontend/public/assets/monster-stage.png`. To replace, add `Frontend/public/game/bg.png`
  (landscape, e.g. 1920×1080).
- **Cabinet frame / crown / trim**: currently drawn with CSS. If you want a custom frame
  image, add `Frontend/public/game/board-frame.png` (transparent PNG) and tell me.

## 3) SOUNDS  → `Frontend/public/game/sounds/`

Right now every sound is generated in code (`Frontend/src/game/sound.ts`) — there are **no
audio files yet**. Please provide real audio (**.mp3 or .ogg**, short, already volume-balanced)
for each event, named exactly:

| File to add | When it plays |
|---|---|
| `spin-start.mp3` | player hits SPIN |
| `reel-stop.mp3` | each reel lands (kept short) |
| `win.mp3` | a normal winning spin |
| `big-win.mp3` | a large win |
| `scatter.mp3` | a **Scatter** lands (big/loud) |
| `wild.mp3` | a **Wild** lands (distinct) |
| `jackpot.mp3` | **Jackpot** — the biggest moment (loudest) |
| `feature.mp3` | free-spins / feature triggers |

Drop them in `Frontend/public/game/sounds/`. When you send it back, I'll replace the
synthesized sounds with your files (and keep the on/off toggle).

## 4) ANIMATIONS / LAYOUT CHANGES

If you want to change how things animate or lay out (symbol landing effects, the
jackpot flash/rays, the win banner, the round timer, fireworks, cabinet layout, etc.), you can
either edit `dune.css` / `SlotStage.tsx` directly, **or** just add a plain-text file named
`DESIGN-NOTES.txt` in this folder describing what you want (with reference screenshots/GIFs if
handy) and I'll implement it.

---

## What NOT to touch
You can ignore all the game logic, math, and backend wiring — none of that is here and none of
it needs to change. Adding assets and adjusting visuals is all that's needed. Keep the folder
names/paths exactly as they are so I can drop everything straight back into the project.
