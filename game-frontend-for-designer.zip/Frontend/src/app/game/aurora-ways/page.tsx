"use client";

import { useRef } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { AuthGuard } from "../../../components/AuthGuard";
import { Logo, Pill } from "../../../components/dune/Shell";
import { SlotStage } from "../../../components/dune/SlotStage";
import { FlipText, useFlipIndex } from "../../../components/dune/FlipText";
import { usePracticeSpin, usePlayNextFreeSpin } from "../../../lib/hooks/useGame";
import { skinFor, coins } from "../../../lib/dune-skins";

// TEMPORARY free-play / practice surface. Reuses the SAME SlotStage as tournament matches,
// so any UI/UX change here applies to the real game. Dummy coins only — no wallet impact.
const START_MINOR = "5000000"; // 50,000 dummy coins (coins() divides by 100)

export default function PracticeGamePage() {
  return (
    <AuthGuard>
      <PracticeGame />
    </AuthGuard>
  );
}

function PracticeGame() {
  const router = useRouter();
  const skin = skinFor("practice");
  const practice = usePracticeSpin();
  const freeSpin = usePlayNextFreeSpin();
  const ko = useFlipIndex(5000) === 1;
  // The dummy balance lives client-side; each spin sends it and gets the new one back.
  const balRef = useRef<string>(START_MINOR);

  return (
    <div className={`game-page ${skin.creature}-theme`}>
      <div className="game-bg" />
      <div className="game-overlay" />
      <header className="game-topbar">
        <button className="game-back" onClick={() => router.push("/home")}>
          <ArrowLeft size={18} />
          <span>
            <FlipText intervalMs={5000} items={[<>Home</>, <>홈</>]} />
          </span>
        </button>
        <div className="game-title">
          <Logo compact />
          <span>Desert Dune · {ko ? "연습 모드" : "Practice mode"}</span>
        </div>
        <div className="game-topstats">
          <span>
            <Pill tone="soon">{ko ? "연습 · 더미 코인" : "PRACTICE · DUMMY COINS"}</Pill>
          </span>
        </div>
      </header>

      <SlotStage
        skin={skin}
        startingCreditsMinor={START_MINOR}
        onSpin={async ({ totalBet }) => {
          const res = await practice.mutateAsync({ totalBet, balance: balRef.current });
          balRef.current = res.newBalance; // track the dummy balance for the next spin
          return res;
        }}
        onFreeSpin={(roundId) => freeSpin.mutateAsync({ roundId })}
      />
      <p style={{ position: "fixed", bottom: 8, left: 0, right: 0, textAlign: "center", fontSize: 11, color: "var(--muted)", zIndex: 5 }}>
        {ko
          ? `연습 모드 — ${coins(START_MINOR).toLocaleString()} 더미 코인으로 시작. 실제 잔액에 영향을 주지 않습니다.`
          : `Practice mode — starts with ${coins(START_MINOR).toLocaleString()} dummy coins. No real balance is affected.`}
      </p>
    </div>
  );
}
